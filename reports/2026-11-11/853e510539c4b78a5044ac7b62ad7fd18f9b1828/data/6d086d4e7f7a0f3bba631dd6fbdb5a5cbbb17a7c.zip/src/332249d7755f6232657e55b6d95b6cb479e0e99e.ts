import { expect, Locator } from "@playwright/test";
import { LoginPage } from "./LoginPage";
import { BasePage } from "./BasePage";

import { standardUser, standardPassword } from "../config/credentials";

class InventoryPageBase extends BasePage {
    static readonly url: string = "/inventory.html";

    get url(): string {
        return InventoryPageBase.url;
    }

    async navigate(): Promise<void> {
        const loginPage = new LoginPage(this.page);
        await loginPage.navigate();
        await loginPage.login(standardUser, standardPassword);
    }
}

export class InventoryPage extends InventoryPageBase {
    locateProductContainer(): Locator {
        return this.page.locator(".inventory_list");
    }

    locateProductItems(): Locator {
        return this.locateProductContainer().locator(".inventory_item");
    }

    locateFirstProduct(): Locator {
        return this.locateProductItems().first();
    }

    locateNthProduct(i: number): Locator {
        return this.locateProductItems().nth(i);
    }

    locateProductImage(product: Locator) {
        return product.locator("img.inventory_item_img");
    }

    locateProductName(product: Locator) {
        return product.locator(".inventory_item_name");
    }

    locateProductNames() {
        return this.locateProductItems().locator(".inventory_item_name");
    }

    locateProductDescription(product: Locator) {
        return product.locator(".inventory_item_description");
    }

    locateProductPrice(product: Locator) {
        return product.locator(".inventory_item_price");
    }

    locateProductPrices() {
        return this.locateProductItems().locator(".inventory_item_price");
    }

    locateProductAddToCartButton(product: Locator) {
        return product.getByRole("button", { name: /^add to cart$/i });
    }

    locateProductRemoveFromCartButton(product: Locator) {
        return product.getByRole("button", { name: "Remove", exact: true });
    }

    locateActiveProductOrderOption() {
        return this.page
            .locator(".select_container")
            .getByTestId("active-option");
    }

    locateProductOrderOptionSelector() {
        return this.page.locator(".select_container").locator("select");
    }

    async addProductToCart(): Promise<void> {
        const availableProducts = this.locateProductItems().filter({
            has: this.page.getByRole("button", { name: /^add to cart$/i }),
        });

        const product = availableProducts.first();
        const productAddToCartButton =
            this.locateProductAddToCartButton(product);

        try {
            await expect(product).toHaveCount(1);
            await expect(productAddToCartButton).toBeVisible();
        } catch (error) {
            throw new Error("Unable to add the product", { cause: error });
        }

        await productAddToCartButton.click();
    }
}
